<?php
return [
 'default'=>env('DB_CONNECTION','mysql'),
 'connections'=>[
  'sqlite'=>['driver'=>'sqlite','url'=>env('DATABASE_URL'),'database'=>env('DB_DATABASE',database_path('database.sqlite')),'prefix'=>'','foreign_key_constraints'=>env('DB_FOREIGN_KEYS',true)],
  'mysql'=>['driver'=>'mysql','url'=>env('DATABASE_URL'),'host'=>env('DB_HOST','127.0.0.1'),'port'=>env('DB_PORT','3306'),'database'=>env('DB_DATABASE','al_asra_befedb'),'username'=>env('DB_USERNAME','root'),'password'=>env('DB_PASSWORD',''),'unix_socket'=>env('DB_SOCKET',''),'charset'=>'utf8mb4','collation'=>'utf8mb4_unicode_ci','prefix'=>'','prefix_indexes'=>true,'strict'=>true,'engine'=>null,'options'=>extension_loaded('pdo_mysql') ? array_filter([PDO::MYSQL_ATTR_SSL_CA=>env('MYSQL_ATTR_SSL_CA')]) : []],
  'pgsql'=>['driver'=>'pgsql','url'=>env('DATABASE_URL'),'host'=>env('DB_HOST','127.0.0.1'),'port'=>env('DB_PORT','5432'),'database'=>env('DB_DATABASE','laravel'),'username'=>env('DB_USERNAME','root'),'password'=>env('DB_PASSWORD',''),'charset'=>'utf8','prefix'=>'','prefix_indexes'=>true,'search_path'=>'public','sslmode'=>'prefer'],
 ],
 'migrations'=>'migrations','redis'=>['client'=>env('REDIS_CLIENT','phpredis'),'options'=>['cluster'=>env('REDIS_CLUSTER','redis'),'prefix'=>env('REDIS_PREFIX','alasra-database-')],'default'=>['url'=>env('REDIS_URL'),'host'=>env('REDIS_HOST','127.0.0.1'),'username'=>env('REDIS_USERNAME'),'password'=>env('REDIS_PASSWORD'),'port'=>env('REDIS_PORT','6379'),'database'=>env('REDIS_DB','0')]],
];
